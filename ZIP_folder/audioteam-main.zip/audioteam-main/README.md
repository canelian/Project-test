https://wb96choi.github.io/audioteam/




메인페이지에 imgslider부분 클래스명이랑 명칭 바꿔야할듯

로그인창은 미완성

메뉴토글창 심볼로고 지랄난거 고치기
= .remove-back css추가로 해결

메뉴창안에 링크넣기

메뉴 서브메뉴 클릭시 메뉴창 사라지는 오류 해결
=진짜 오류같으니 보류

상세페이지 margin-bottom좀만더주기